package com.palmergames.bukkit.towny.object.spawnlevel;

public enum SpawnLevel {
	TRUE,
	FALSE,
	WAR,
	PEACE
}
