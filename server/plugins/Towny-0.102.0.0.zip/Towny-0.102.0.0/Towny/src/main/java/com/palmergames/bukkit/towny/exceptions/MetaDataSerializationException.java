package com.palmergames.bukkit.towny.exceptions;

public class MetaDataSerializationException extends TownyException {
	private static final long serialVersionUID = -5272182994988841260L;
    
}
